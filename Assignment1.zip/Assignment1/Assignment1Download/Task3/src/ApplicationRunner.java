
import java.io.File;

public class ApplicationRunner {

    public static void main(String[] args) {

        String dataFile = System.getProperty("user.dir") + File.separator + "lexicon.txt";

    }
    
}
